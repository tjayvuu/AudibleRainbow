package com.example.acer.savehinhve;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    // Activity request codes
    private static final int CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
    private static final int CAMERA_CAPTURE_VIDEO_REQUEST_CODE = 200;
    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;

    private Uri fileUri; // file url to store image/video

    private ImageView imgPreview;
    private Button btnCapturePicture;

    // directory name to store captured images and videos
    private static final String IMAGE_DIRECTORY_NAME = "Hello Camera";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgPreview = (ImageView) findViewById(R.id.imgPreview);
        btnCapturePicture = (Button) findViewById(R.id.btnCapturePicture);

        btnCapturePicture.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // capture picture
                captureImage();

                //yellow
//                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

//                ImageView image =(ImageView)findViewById(R.id.image);

                //encode image to base64 string
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                int imgID = imageViewToInt(imgPreview);
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), imgID);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageBytes = baos.toByteArray();
                String imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);

                //decode base64 string to image
//                imageBytes = Base64.decode(imageString, Base64.DEFAULT);
//                Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
//                image.setImageBitmap(decodedImage);



                // test api
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        // All your networking logic
                        // should be here
                        // Create URL

                        // call ColorNameAPI
                        try {
                            Log.d("myTag00", "This is my message");
                            String rgb = getImageAnalysis();
                            getName(rgb);
                            Log.d("myTag01", "This is my message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        });
    }
    private void captureImage() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE);

        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);

        // start the image capture Intent
        startActivityForResult(intent, CAMERA_CAPTURE_IMAGE_REQUEST_CODE);
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // save file url in bundle as it will be null on scren orientation
        // changes
        outState.putParcelable("file_uri", fileUri);
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        // get the file url
        fileUri = savedInstanceState.getParcelable("file_uri");
    }
    public Uri getOutputMediaFileUri(int type) {
        return Uri.fromFile(getOutputMediaFile(type));
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // if the result is capturing Image
        if (requestCode == CAMERA_CAPTURE_IMAGE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // successfully captured the image
                // display it in image view
                previewCapturedImage();
            } else if (resultCode == RESULT_CANCELED) {
                // user cancelled Image capture
                Toast.makeText(getApplicationContext(),
                        "User cancelled image capture", Toast.LENGTH_SHORT)
                        .show();
            } else {
                // failed to capture image
                Toast.makeText(getApplicationContext(),
                        "Sorry! Failed to capture image", Toast.LENGTH_SHORT)
                        .show();
            }
        }
    }
    private void previewCapturedImage() {
        try {
            // hide video preview

            imgPreview.setVisibility(View.VISIBLE);

            // bimatp factory
            BitmapFactory.Options options = new BitmapFactory.Options();

            // downsizing image as it throws OutOfMemory Exception for larger
            // images
            options.inSampleSize = 8;

            final Bitmap bitmap = BitmapFactory.decodeFile(fileUri.getPath(),
                    options);

            imgPreview.setImageBitmap(bitmap);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }


    /*
     * Here we restore the fileUri again
     */


    /*
     * returning image / video
     */
    private static File getOutputMediaFile(int type) {

        // External sdcard location
        File mediaStorageDir = new File(
                Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                IMAGE_DIRECTORY_NAME);

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d(IMAGE_DIRECTORY_NAME, "Oops! Failed create "
                        + IMAGE_DIRECTORY_NAME + " directory");
                return null;
            }
        }

        // Create a media file name

        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator
                    + "IMG_" + ".jpg");
        } else if (type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator
                    + "VID_" + ".mp4");
        } else {
            return null;
        }

        return mediaFile;
    }

    // yellow
    public static String getImageAnalysis() throws Exception {
        final String TARGET_URL =
                "https://vision.googleapis.com/v1/images:annotate?";
        final String API_KEY =
                "key=AIzaSyD-B5rGzWRSXmbJIIQ5mCgeq1h20KAzMuQ";

        URL serverUrl = new URL(TARGET_URL + API_KEY);
//		URLConnection urlConnection = serverUrl.openConnection();

        HttpURLConnection httpConnection = (HttpURLConnection) serverUrl.openConnection();
        System.setProperty("http.agent", "Mozilla/5.0");

//		HttpURLConnection httpConnection = (HttpURLConnection)urlConnection;

        httpConnection.setRequestMethod("POST");
        httpConnection.setRequestProperty("Content-Type", "application/json");
        httpConnection.setDoOutput(true);
        BufferedWriter httpRequestBodyWriter = new BufferedWriter(new
                OutputStreamWriter(httpConnection.getOutputStream()));
        httpRequestBodyWriter.write
                ("{\"requests\":  [{ \"features\":  [ {\"type\": \"IMAGE_PROPERTIES\""
                        +"}], \"image\": {\"source\": { \"gcsImageUri\":"
                        +" \"gs://vimagebucket/istock.jpg\"}}}]}");
        httpRequestBodyWriter.close();
        String resp = httpConnection.getResponseMessage();

        if (httpConnection.getInputStream() == null) {
            System.out.println("No stream");
            return "";
        }

        Scanner httpResponseScanner = new Scanner(httpConnection.getInputStream());
        String resp1 = "";
        while (httpResponseScanner.hasNext()) {
            String line = httpResponseScanner.nextLine();
            resp1 += line;
//			   System.out.println(line);  //  alternatively, print the line of response
        }
        httpResponseScanner.close();
        // parse json
        JSONObject obj = new JSONObject(resp1);


        JSONObject res = obj.getJSONArray("responses").getJSONObject(0).getJSONObject("imagePropertiesAnnotation")
                .getJSONObject("dominantColors").getJSONArray("colors").getJSONObject(0).getJSONObject("color")
                ;
        int r = res.getInt("red");
        int g = res.getInt("green");
        int b = res.getInt("blue");
        String rgb = "rgb" + "(" + r + "," + g + "," + b + ")";
        Log.d("myTagYellow", rgb);
        return rgb;
//        System.out.println(rgb);
    }

    // Use ColorNameAPI to get color nam from RGB code
    public static void getName(String rgb) throws Exception {

//		HttpURLConnectionExample http = new HttpURLConnectionExample();
//
//		System.out.println("Testing 1 - Send Http GET request");
//		http.sendGet();
//
//
//	}
//
//	// HTTP GET request
//	private void sendGet() throws Exception {

//		String url = "http://www.google.com/search?q=mkyong";
        String url = "http://thecolorapi.com/id?rgb=" + rgb;

        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("GET");

        //add request header
//		con.setRequestProperty("User-Agent", USER_AGENT);

        int responseCode = con.getResponseCode();
        Log.d("myTagCN11", "" + responseCode);
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        //print result
        System.out.println(response.toString());
        String str = response.toString();
        JSONObject j_obj = new JSONObject(str);


        JSONObject res = j_obj.getJSONObject("name");
        System.out.println(res.getString("value"));
        Log.d("myTag99", res.getString("value"));


    }

    public static int imageViewToInt(ImageView imageView) {
        imageView.setTag(R.drawable.yellow);
        return (Integer) imageView.getTag();
    }

}
